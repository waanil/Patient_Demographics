﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Patient_Demographics_Domain.Models;
using Patient_Demographics_Service.Interfaces;

namespace Patient_Demographics.Controllers
{
    [Route("api/[controller]")]
    public class PatientController : Controller
    {
        IPatientService _patientService;
        public PatientController(IPatientService PatientService)
        {
            _patientService = PatientService;
        }
        // GET api/values
        [HttpGet]
        public Patient Get()
        {
            return new Patient { ForeName = "Anil", SurName = "Kumar", DateOfBirth = DateTime.Now, Gender = GenderEnum.Male };
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {

            var patient = _patientService.GetPatientByID(id);

            if (patient != null)
            {
                return Ok(patient);
            }

            else
            {
                return NotFound(id);
            }
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]Patient patient)
        {
            if (ModelState.IsValid)
            {
                // Do something with the product (not shown).
                var result = _patientService.CreatePatrients(patient);

                return Ok(result);
            }
            else
            {
                return BadRequest(ModelState);
            }

        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
