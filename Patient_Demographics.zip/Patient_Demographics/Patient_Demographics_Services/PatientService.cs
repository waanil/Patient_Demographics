﻿using System;
using System.Collections.Generic;
using Patient_Demographics_Domain.Models;
using Patient_Demographics_Domain.Interfaces;
using Patient_Demographics_Service.Interfaces;

namespace Patient_Demographics_Services
{
    public class PatientService : IPatientService
    {
        IPatientRepository _patientRepo;
        public PatientService(IPatientRepository patientRepo)
        {
            _patientRepo = patientRepo;
        }
        public Patient CreatePatrients(Patient patient)
        {

            string tempGUID =  Guid.NewGuid().ToString();
            try
            {
                patient.PatientGUIID = tempGUID;
                _patientRepo.CreatePatrients(patient);
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return patient;
        }

        public bool DeletePatientByID(string patientGUID)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Patient> GetAllPatients()
        {
            throw new NotImplementedException();
        }

        public Patient GetPatientByID(string patientGUID)
        {
            Patient patient = _patientRepo.GetPatientByID(patientGUID);
            return patient;
        }

        public Patient UpdatePatient(Patient patient)
        {
            throw new NotImplementedException();
        }
    }
}
