﻿using System;
using System.Collections.Generic;
using Patient_Demographics_Domain.Models;
using Patient_Demographics_Domain.Interfaces;
using System.Xml.Serialization;
using System.IO;
using Patient_Demographics_Infrastructure.Entities;
using System.Linq;

namespace Patient_Demographics_Test
{
    public class TestRepo : IPatientRepository
    {
        private static List<PatientEntity> patients = new List<PatientEntity>();
         
        public string CreatePatrients(Patient patient)
        {


            var stringwriter = new System.IO.StringWriter();
            var serializer = new XmlSerializer(patient.GetType());
            serializer.Serialize(stringwriter, patient);
            patients.Add(new PatientEntity {ID = patients.Count+1, Patient_XML= stringwriter.ToString() });
            return stringwriter.ToString();
        }

        public bool DeletePatientByID(string patientGUIID)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Patient> GetAllPatients()
        {
            throw new NotImplementedException();
        }

        public Patient GetPatientByID(string patientGUID)
        {
            Patient patient = null;
            for (int i = 0; i <= patients.Count - 1; i++)
            {
                StringReader stringReader = new StringReader(patients[i].Patient_XML.ToString());
                XmlSerializer serializer = new XmlSerializer(typeof(Patient), new XmlRootAttribute("Patient"));
                patient = (Patient)serializer.Deserialize(stringReader);
                if(patient.PatientGUIID == patientGUID)
                break;

            }
            return patient;

        }

        public Patient UpdatePatient(Patient patient)
        {
            throw new NotImplementedException();
        }
    }
}
