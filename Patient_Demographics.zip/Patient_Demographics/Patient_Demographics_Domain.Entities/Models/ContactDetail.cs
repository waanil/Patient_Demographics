﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Patient_Demographics_Domain.Models
{
    public class ContactDetail
    {
        [Required(ErrorMessage = "ContactType is required")]
        public string ContactType { get; set; }

       /* [RegularExpression(@"([0-9]+)", ErrorMessage = "Must be a Number")]
        [MaxLength(10)]
        [MinLength(0)]
        [DataType(DataType.PhoneNumber)]*/
        public int ContactNumber { get; set; }
    }
}