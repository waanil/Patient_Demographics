﻿using System;
using System.Collections.Generic;
using Patient_Demographics_Domain.Models;
using Patient_Demographics_Domain.Interfaces;
using System.Xml.Serialization;
using System.IO;

namespace Patient_Demographics_Infrastructure
{
    public class Patient_SQL_Repository : IPatientRepository
    {
        public string CreatePatrients(Patient patient)
        {
            var stringwriter = new System.IO.StringWriter();
            var serializer = new XmlSerializer(patient.GetType());
            serializer.Serialize(stringwriter, patient);

            return stringwriter.ToString();
        }

        public bool DeletePatientByID(string patientGUIID)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Patient> GetAllPatients()
        {
            throw new NotImplementedException();
        }

        public Patient GetPatientByID(string patientGUID)
        {
            StringReader stringReader = new StringReader("xx");
            XmlSerializer serializer = new XmlSerializer(typeof(List<Patient>), new XmlRootAttribute("Patient"));
            Patient patient = (Patient)serializer.Deserialize(stringReader);
            return patient;
        }

        public Patient UpdatePatient(Patient patient)
        {
            throw new NotImplementedException();
        }
    }
}
