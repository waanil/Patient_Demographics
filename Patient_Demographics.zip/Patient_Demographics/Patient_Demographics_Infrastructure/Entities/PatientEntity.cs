﻿using System;
namespace Patient_Demographics_Infrastructure.Entities
{
    public class PatientEntity
    {
       public int ID { get; set; }
       public string Patient_XML { get; set; }
    }
}
