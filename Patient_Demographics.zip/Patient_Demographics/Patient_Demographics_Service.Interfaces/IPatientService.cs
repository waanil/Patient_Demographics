﻿using System;
using System.Collections.Generic;
using Patient_Demographics_Domain.Models;


namespace Patient_Demographics_Service.Interfaces
{
    public interface IPatientService
    {
        //this method will return the GUID string on succefull creation of Patien
        Patient CreatePatrients(Patient patient);
        IEnumerable<Patient> GetAllPatients();
        Patient GetPatientByID(string patientGUIID);
        Boolean DeletePatientByID(string patientGUIID);
        Patient UpdatePatient(Patient patient);
    }
}
